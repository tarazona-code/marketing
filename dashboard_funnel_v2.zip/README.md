# Diagnóstico Radical del Funnel — Dashboard (versión ligera)

Dashboard interactivo (Streamlit) sin dependencias externas problemáticas:
usa solo streamlit + pandas y gráficas nativas. Datos en CSV.

## Archivos a subir a GitHub (los 3, en la RAÍZ del repo)
- app.py
- requirements.txt
- datos_atribucion_crudos.csv

## Desplegar (gratis, ~3 min)
1. Sube los 3 archivos a la raíz de tu repo de GitHub.
2. share.streamlit.io -> login con GitHub -> Create app.
3. Repo + Main file path: app.py -> Deploy.

## Local
pip install -r requirements.txt
streamlit run app.py
